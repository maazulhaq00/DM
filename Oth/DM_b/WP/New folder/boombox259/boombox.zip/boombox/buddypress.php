<?php
/**
 * The template for displaying buddypress pages content
 * @package BoomBox_Theme
 * @since   1.0.0
 * @version 2.0.0
 */

get_header();

the_post();

the_content();

get_footer();