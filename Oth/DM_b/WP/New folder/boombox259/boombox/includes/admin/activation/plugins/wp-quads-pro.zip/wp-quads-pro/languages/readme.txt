********************************************************

  WP QUADS PRO I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Quick AdSense Reloaded updates.
  
  Keep custom QUADS translations in /wp-content/languages/wp-quads-pro/
  
  You want to translate, help, or improve a translation?
  Write: support@wpquads.com

********************************************************
