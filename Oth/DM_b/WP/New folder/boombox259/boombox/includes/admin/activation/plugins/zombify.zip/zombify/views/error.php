<h1><?php echo $error_title; ?></h1>
<?php echo $error_msg; ?>