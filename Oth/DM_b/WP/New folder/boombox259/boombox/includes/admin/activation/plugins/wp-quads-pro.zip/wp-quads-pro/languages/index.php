<?php
/**
 * Do not put custom translations here. They will be deleted on WP QUADS PRO updates.
 *
 * Keep custom WP QUADS PRO translations in /wp-content/languages/wp-quads-pro
 */