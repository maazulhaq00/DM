<div class="zf-story_item">
    <h2 class="zf_title"><?php echo $story_data["text_title"]; ?></h2>
    <div class="zf_description">
        <?php echo $story_data["text_description"]; ?>
    </div>
</div>